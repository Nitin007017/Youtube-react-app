# FULL STACK COURSE 2023

  

Hi, This is **CoderDost Youtube Channel** Full Stack Development Course [Course Link ](https://youtube.com/coderdost),

  

You can **download code** from here via :

1. Git Commands

- use `git clone <repository_url>`

- checkout branch according to video `git checkout react-1` [e.g. for chapter-1]

- run `npm install` inside the root directory before running the code

  

2. If you are not comfortable with git, directly download the branch as Zip.

- Choose branch related to the Video e.g. `react-1` [e.g. for chapter-1]

- run `npm install` inside the root directory before running the code

  
  